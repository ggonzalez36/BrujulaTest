package exception;

public class BrujulaException extends Exception{

	
	public BrujulaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
